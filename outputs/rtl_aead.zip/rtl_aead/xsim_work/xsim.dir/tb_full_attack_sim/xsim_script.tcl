xsim {tb_full_attack_sim} -autoloadwcfg -runall
