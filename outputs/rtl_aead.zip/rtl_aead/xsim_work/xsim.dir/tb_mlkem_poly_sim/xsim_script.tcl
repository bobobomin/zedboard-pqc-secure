xsim {tb_mlkem_poly_sim} -autoloadwcfg -runall
