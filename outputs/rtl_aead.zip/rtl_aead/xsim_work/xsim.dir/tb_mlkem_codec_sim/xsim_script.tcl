xsim {tb_mlkem_codec_sim} -autoloadwcfg -runall
