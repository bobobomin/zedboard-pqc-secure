xsim {tb_reenc_sim} -autoloadwcfg -runall
