xsim {tb_kpke_dec_sim} -autoloadwcfg -runall
