xsim {tb_decaps_sim} -autoloadwcfg -runall
