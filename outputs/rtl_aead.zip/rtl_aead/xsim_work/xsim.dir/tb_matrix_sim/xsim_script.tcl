xsim {tb_matrix_sim} -autoloadwcfg -runall
