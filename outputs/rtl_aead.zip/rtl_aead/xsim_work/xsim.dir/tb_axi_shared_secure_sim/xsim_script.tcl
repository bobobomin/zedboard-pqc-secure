xsim {tb_axi_shared_secure_sim} -autoloadwcfg -runall
