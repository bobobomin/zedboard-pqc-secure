xsim {tb_axi_secure_sim} -autoloadwcfg -runall
