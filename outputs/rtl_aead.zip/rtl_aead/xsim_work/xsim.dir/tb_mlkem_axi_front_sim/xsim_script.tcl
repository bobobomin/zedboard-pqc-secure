xsim {tb_mlkem_axi_front_sim} -autoloadwcfg -runall
