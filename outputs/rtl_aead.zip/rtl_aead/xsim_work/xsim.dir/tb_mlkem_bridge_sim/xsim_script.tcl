xsim {tb_mlkem_bridge_sim} -autoloadwcfg -runall
