xsim {tb_sha3_shake_sim} -autoloadwcfg -runall
