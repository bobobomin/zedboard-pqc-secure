xsim {tb_mlkem_hashg_sim} -autoloadwcfg -runall
