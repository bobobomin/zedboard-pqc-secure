xsim {tb_aead_fixed64_sim} -autoloadwcfg -runall
