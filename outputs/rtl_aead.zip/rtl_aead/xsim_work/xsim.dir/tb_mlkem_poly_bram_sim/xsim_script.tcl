xsim {tb_mlkem_poly_bram_sim} -autoloadwcfg -runall
