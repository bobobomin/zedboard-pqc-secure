xsim {tb_aead_axi_sim} -autoloadwcfg -runall
