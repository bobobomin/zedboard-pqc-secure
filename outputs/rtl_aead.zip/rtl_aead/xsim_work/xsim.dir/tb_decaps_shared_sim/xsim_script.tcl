xsim {tb_decaps_shared_sim} -autoloadwcfg -runall
