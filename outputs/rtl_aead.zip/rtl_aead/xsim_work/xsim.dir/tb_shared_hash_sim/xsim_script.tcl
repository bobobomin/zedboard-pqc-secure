xsim {tb_shared_hash_sim} -autoloadwcfg -runall
