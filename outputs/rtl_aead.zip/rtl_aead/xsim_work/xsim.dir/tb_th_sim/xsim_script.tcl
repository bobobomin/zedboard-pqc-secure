xsim {tb_th_sim} -autoloadwcfg -runall
