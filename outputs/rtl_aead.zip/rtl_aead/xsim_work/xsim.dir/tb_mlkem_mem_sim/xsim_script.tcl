xsim {tb_mlkem_mem_sim} -autoloadwcfg -runall
