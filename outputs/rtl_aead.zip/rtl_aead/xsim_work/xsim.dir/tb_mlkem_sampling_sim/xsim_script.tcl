xsim {tb_mlkem_sampling_sim} -autoloadwcfg -runall
