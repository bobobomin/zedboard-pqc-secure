xsim {tb_noise_sim} -autoloadwcfg -runall
