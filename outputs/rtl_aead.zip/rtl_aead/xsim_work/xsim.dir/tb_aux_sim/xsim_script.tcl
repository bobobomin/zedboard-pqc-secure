xsim {tb_aux_sim} -autoloadwcfg -runall
