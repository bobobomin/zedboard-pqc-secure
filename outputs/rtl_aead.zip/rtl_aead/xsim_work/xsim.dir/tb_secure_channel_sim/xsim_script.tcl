xsim {tb_secure_channel_sim} -autoloadwcfg -runall
