xsim {tb_aead_arbiter_sim} -autoloadwcfg -runall
