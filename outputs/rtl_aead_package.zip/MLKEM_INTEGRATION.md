# ML-KEM integration boundary

The working demo is a PS/PL co-design:

```text
PC: ML-KEM Encaps -> (ciphertext, shared secret)
                    Ethernet
Zynq PS: ML-KEM Decaps + transcript SHA3-256
                    AXI-Lite
Zynq PL: SHAKE256 KDF -> four-session table -> ChaCha20-Poly1305
```

`mlkem_poly_accelerator.sv` implements the dominant polynomial kernels needed
to move Decaps into PL incrementally. It provides forward NTT, inverse NTT and
base multiplication over q=3329, n=256, verified against the mlkem-native
reference arithmetic. Its small host interface is intended for a BRAM/AXI
adapter; it is not silently used by the current PS software build.

This split gives a testable end-to-end system now while retaining a genuine
ML-KEM hardware-acceleration path. It also avoids presenting an unverified
monolithic KeyGen/Decaps FSM as completed security hardware.
