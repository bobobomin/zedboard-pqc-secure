# Implementation status

Completed and regression-tested:

- deterministic PC golden reference using mlkem-native and Monocypher;
- ChaCha20, Poly1305 and authenticate-before-release AEAD RTL;
- four independent session slots, direction-separated keys/nonces/counters,
  replay rejection and round-robin arbitration;
- AXI4-Lite wrapper and bare-metal PS driver;
- Keccak-f[1600], SHA3-256/512 and SHAKE128/256 RTL with KATs;
- ML-KEM-512 forward NTT, inverse NTT and BaseMul accelerator using three
  true dual-port BRAMs;
- SHAKE256 session KDF connected from ML-KEM shared secret/transcript hash
  through AXI into the session table and AEAD engine.

Current demo boundary:

- PC performs ML-KEM Encaps;
- Zynq PS performs standards-compliant ML-KEM Decaps and transcript hashing;
- PL performs the session KDF, key installation, packet protection and replay
  checks;
- the polynomial accelerator is verified as a standalone PL offload kernel but
  still needs an AXI-BRAM adapter before PS Decaps can call it.

Not claimed as complete: a fully autonomous, monolithic RTL KeyGen/Decaps FSM,
Ethernet/lwIP application code, DMA, or the final fault-injection layer.
