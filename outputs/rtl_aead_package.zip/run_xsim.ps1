$ErrorActionPreference = 'Stop'

$VivadoBin = 'C:\Xilinx\Vivado\2020.2\bin'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Work = Join-Path $Root 'xsim_work'

New-Item -ItemType Directory -Force -Path $Work | Out-Null
Push-Location $Work
try {
    & (Join-Path $VivadoBin 'xvlog.bat') -sv `
        (Join-Path $Root 'rtl\chacha20_block.sv') `
        (Join-Path $Root 'rtl\poly1305_fixed96.sv') `
        (Join-Path $Root 'rtl\aead_fixed64_wrapper.sv') `
        (Join-Path $Root 'rtl\aead_fixed64_decrypt_wrapper.sv') `
        (Join-Path $Root 'rtl\aead_fixed64_engine.sv') `
        (Join-Path $Root 'rtl\aead_arbiter_4session.sv') `
        (Join-Path $Root 'rtl\aead_axi_lite_wrapper.sv') `
        (Join-Path $Root 'rtl\keccak_f1600.sv') `
        (Join-Path $Root 'rtl\sha3_shake_stream.sv') `
        (Join-Path $Root 'rtl\mlkem_poly_accelerator.sv') `
        (Join-Path $Root 'rtl\mlkem_session_kdf.sv') `
        (Join-Path $Root 'rtl\secure_channel_core.sv') `
        (Join-Path $Root 'tb\tb_aead_arbiter_4session.sv') `
        (Join-Path $Root 'tb\tb_aead_axi_lite_wrapper.sv') `
        (Join-Path $Root 'tb\tb_aead_fixed64.sv') `
        (Join-Path $Root 'tb\tb_sha3_shake_stream.sv') `
        (Join-Path $Root 'tb\tb_mlkem_poly_accelerator.sv') `
        (Join-Path $Root 'tb\tb_secure_channel_core.sv')
    if ($LASTEXITCODE -ne 0) { throw 'xvlog failed' }

    & (Join-Path $VivadoBin 'xelab.bat') tb_aead_fixed64 -s tb_aead_fixed64_sim
    if ($LASTEXITCODE -ne 0) { throw 'xelab failed' }

    & (Join-Path $VivadoBin 'xsim.bat') tb_aead_fixed64_sim -runall
    if ($LASTEXITCODE -ne 0) { throw 'xsim failed' }

    & (Join-Path $VivadoBin 'xelab.bat') tb_aead_arbiter_4session -s tb_aead_arbiter_sim
    if ($LASTEXITCODE -ne 0) { throw 'arbiter xelab failed' }

    & (Join-Path $VivadoBin 'xsim.bat') tb_aead_arbiter_sim -runall
    if ($LASTEXITCODE -ne 0) { throw 'arbiter xsim failed' }

    & (Join-Path $VivadoBin 'xelab.bat') tb_aead_axi_lite_wrapper -s tb_aead_axi_sim
    if ($LASTEXITCODE -ne 0) { throw 'AXI xelab failed' }

    & (Join-Path $VivadoBin 'xsim.bat') tb_aead_axi_sim -runall
    if ($LASTEXITCODE -ne 0) { throw 'AXI xsim failed' }

    & (Join-Path $VivadoBin 'xelab.bat') tb_sha3_shake_stream -s tb_sha3_shake_sim
    if ($LASTEXITCODE -ne 0) { throw 'SHA3 xelab failed' }

    & (Join-Path $VivadoBin 'xsim.bat') tb_sha3_shake_sim -runall
    if ($LASTEXITCODE -ne 0) { throw 'SHA3 xsim failed' }

    & (Join-Path $VivadoBin 'xelab.bat') tb_mlkem_poly_accelerator -s tb_mlkem_poly_sim
    if ($LASTEXITCODE -ne 0) { throw 'ML-KEM polynomial xelab failed' }

    & (Join-Path $VivadoBin 'xsim.bat') tb_mlkem_poly_sim -runall
    if ($LASTEXITCODE -ne 0) { throw 'ML-KEM polynomial xsim failed' }

    & (Join-Path $VivadoBin 'xelab.bat') tb_secure_channel_core -s tb_secure_channel_sim
    if ($LASTEXITCODE -ne 0) { throw 'secure-channel xelab failed' }

    & (Join-Path $VivadoBin 'xsim.bat') tb_secure_channel_sim -runall
    if ($LASTEXITCODE -ne 0) { throw 'secure-channel xsim failed' }
}
finally {
    Pop-Location
}
