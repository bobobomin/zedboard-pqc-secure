# Implementation status

## Functionally complete and regression-tested

- ChaCha20-Poly1305 AEAD with authenticate-before-release decryption;
- four session slots, direction-separated keys/nonces/counters, replay checks
  and round-robin arbitration;
- SHA3-256/512 and SHAKE128/256;
- ML-KEM-512 codec, CBD sampling, matrix generation, noise generation,
  NTT, inverse NTT and BaseMul;
- complete K-PKE.Decrypt and deterministic K-PKE re-encryption;
- regenerated-ciphertext compression and constant-time 768-byte comparison;
- `G(m || H(ek))`, public-key hash check and `J(z || ciphertext)`;
- implicit-rejection selection of the final 32-byte shared secret;
- SHA3-256 transcript hash over `ek || ciphertext || session_id_be`;
- DMA-free AXI4-Lite loading of the 1,632-byte SK and 768-byte ciphertext;
- automatic session KDF and atomic installation into the selected AEAD slot.

The full valid-vector Decaps test returns
`ee5f8f90...99dee4f`. A one-bit-modified ciphertext is rejected and returns
the independently calculated rejection secret. The AXI integration test loads
the complete SK and ciphertext, performs Decaps in PL, installs slot 0 and
then reproduces the golden ChaCha20-Poly1305 packet. The complete regression
suite passes in Vivado XSim.

## Stage status

- Stage 6, ML-KEM RTL: functionally complete and KAT-verified.
- Stage 7, PS-PL AXI-Lite connection: functionally complete and integration-
  verified without DMA.
- Stage 8, Ethernet/lwIP: not started.
- Stage 9, fault protection: not started.

## ZedBoard synthesis constraint

The current functional top instantiates seven independent Keccak/SHA3/SHAKE
engines even though their operations execute sequentially. Vivado completes
RTL synthesis with zero logic errors, but the pre-report cell summary contains
123,731 primitive LUT cells versus 53,200 LUTs on the XC7Z020. DSP and memory
are not the limiting resources: 71/220 DSP48E1, six RAMB18E1 and four
RAMB36E1 were reported.

Therefore this version is a complete behavioral/RTL integration reference,
but it is not yet a ZedBoard-fit bitstream. Before implementation, the hash
users must be connected to one shared Keccak engine through a small command
arbiter. That optimization does not change the verified ML-KEM or AXI protocol
sequence; it removes duplicated datapaths.
