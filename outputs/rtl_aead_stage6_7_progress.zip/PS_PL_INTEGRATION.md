# ZedBoard PS-PL integration steps

## Vivado block design

1. Add every SystemVerilog file under `rtl/` to the project.
2. Package `aead_axi_lite_wrapper` as a custom AXI4-Lite peripheral.
3. Create a block design containing `ZYNQ7 Processing System`.
4. Run PS block automation for DDR and FIXED_IO.
5. Enable `M_AXI_GP0` and `FCLK_CLK0` in the PS configuration.
6. Connect `M_AXI_GP0` through AXI Interconnect/SmartConnect to this peripheral.
7. Drive `s_axi_aclk` from `FCLK_CLK0` and use a Processor System Reset block
   for `s_axi_aresetn`.
8. Assign the peripheral an address such as `0x43C00000`.
9. Generate the HDL wrapper and bitstream, then export the XSA to Vitis.

The final address generated in `xparameters.h` must replace the fallback
address in `ps_driver/example_baremetal.c`.

## Vitis application

Add these files to a bare-metal application:

```text
ps_driver/aead_hw.h
ps_driver/aead_hw.c
```

After PS-side ML-KEM Decaps completes, calculate the transcript hash and call
`aead_hw_install_mlkem_session`. PL performs SHAKE256 KDF, separates the two
directions, and installs the selected session slot. Ethernet software can then
keep received packets in DDR and call `aead_hw_encrypt` or
`aead_hw_decrypt` one at a time.

## Current transfer method

The 64-byte data area is transferred as sixteen 32-bit AXI4-Lite accesses.
There is no DMA and no PL request FIFO in this version. Software must wait for
the current request to finish before submitting another request.
