# Implementation status

## Completed and regression-tested

- deterministic PC golden reference using mlkem-native and Monocypher;
- ChaCha20, Poly1305 and authenticate-before-release AEAD RTL;
- four independent session slots, direction-separated keys/nonces/counters,
  replay rejection and round-robin arbitration;
- AXI4-Lite AEAD wrapper and bare-metal PS driver;
- Keccak-f[1600], SHA3-256/512 and SHAKE128/256 RTL with KATs;
- ML-KEM-512 forward NTT, inverse NTT and BaseMul accelerator;
- ML-KEM codec primitives for d10/d4 compression and 12-bit polynomial
  serialization;
- eta2/eta3 CBD sampling, SHAKE-based matrix generation and noise generation;
- shared secret-key, ciphertext and 12-slot polynomial BRAM subsystem;
- complete K-PKE.Decrypt datapath in PL: unpack, NTT, BaseMul, accumulation,
  INTT, subtraction and message recovery;
- SHA3-512 `G(m || H(ek))` derivation;
- DMA-free AXI4-Lite loader for the 1,632-byte secret key and 768-byte
  ciphertext, plus its bare-metal PS driver.

The K-PKE.Decrypt engine was checked using the complete binary secret key and
ciphertext from the project golden reference. It recovered the expected
32-byte message `a0 a1 ... bf`. All older AEAD, arbiter, AXI, SHA3/SHAKE and
polynomial tests continue to pass.

## Current hardware boundary

The new PL path now reaches the following verified point:

```text
PS writes sk + ct through AXI-Lite
  -> PL unpacks ct and PKE secret key
  -> K-PKE.Decrypt in PL
  -> recovered m
  -> SHA3-512 G(m || H(ek))
  -> candidate K and re-encryption coins
```

This is the front half of standards-compliant ML-KEM-512 Decaps. It is not yet
the final Decaps output.

## Remaining for stage 6 completion

- unpack the embedded public key from the ML-KEM secret key;
- deterministic K-PKE re-encryption using the recovered message and coins;
- pack the regenerated ciphertext and compare all 768 bytes;
- compute the rejection secret from `z || ct`;
- constant-time selection between the candidate and rejection secrets;
- final ML-KEM KDF and a valid/tampered-ciphertext KAT.

## Remaining for stage 7 completion

- connect the final Decaps result to the existing session KDF/table;
- make a successful Decaps atomically install the selected AEAD session;
- expose final status/failure signals through the AXI-Lite wrapper;
- synthesize and verify the combined top on the ZedBoard design.

DMA is intentionally not part of this milestone. Ethernet/lwIP and the final
fault-injection layer remain stages 8 and 9.
