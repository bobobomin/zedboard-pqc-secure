# XC7Z020 synthesis checkpoint

Vivado 2020.2 successfully elaborated and synthesized the encryption wrapper
and its ChaCha20/Poly1305 cores for `xc7z020clg484-1` with no RTL synthesis
warnings. The tool reported the following cell counts before a local Vivado
temporary-directory cleanup issue stopped report-file generation:

```text
DSP48E1     4
FDCE        5000
LUT1..LUT6  4360 total primitive LUT cells
CARRY4      660
```

These figures are an early out-of-context estimate. The top currently exposes
995 input and 642 output bits directly, so final utilization and timing must be
measured after replacing the wide test ports with the project AXI/BRAM wrapper
and adding clock constraints.

The important architectural result is that the serialized radix-2^26
Poly1305 datapath reduced inferred DSP48E1 use from 64 in the initial direct
wide-multiply baseline to 4 while preserving the C golden tag.

The four-session arbiter plus shared AEAD engine was also synthesized through
Vivado RTL synthesis. The pre-report cell summary showed 4 DSP48E1, 12,441
flip-flops, and 11,207 primitive LUT cells. These numbers include very large
multiplexers and 3,474 input/2,833 output buffers caused by the deliberately
wide simulation top. They are not the expected AXI-integrated result.

The Poly1305 "unconnected input bits" warnings correspond to bits removed by
the standard `r` clamp mask. Constant-output warnings come from reserved AAD
bytes and fixed packet lengths; neither indicates a functional mismatch.

The AXI4-Lite top including the SHAKE256 session KDF was synthesized for
`xc7z020clg484-1`. Vivado's pre-report cell summary reported 4 DSP48E1,
32,470 primitive LUT cells, and 24,680 flip-flops. This is substantially larger
than the AEAD-only baseline because one full Keccak round is evaluated per
cycle, but remains inside the XC7Z020 raw LUT/FF capacity.
Only 63 input and 41 output buffers remained at the AXI top, confirming that
the earlier thousands of I/O buffers were caused by the simulation-only wide
ports. The result has no timing constraint yet and the session table is still
implemented in registers, so these are integration-baseline figures rather
than final place-and-route utilization.

In this local Vivado 2020.2 installation, synthesis reports completion and the
cell summary before a tool-side `.Xil/realtime/tmp` cleanup error terminates the
batch command. RTL synthesis itself reports zero errors and zero critical
warnings; final reports should be regenerated inside the normal Vivado project.

The first polynomial-kernel memory style dissolved the three coefficient banks
into registers and exceeded the board LUT budget. The corrected design uses
explicit true dual-port synchronous memories. Vivado recognizes three 256x16
RAM templates and reports this compact standalone ML-KEM kernel summary:

```text
RAMB18E1       3
DSP48E1       26
LUT1..LUT6   754 total primitive LUT cells
flip-flops    184
```

The additional read/write phase doubles butterfly latency but makes the NTT,
inverse NTT and BaseMul accelerator practical on the ZedBoard.
