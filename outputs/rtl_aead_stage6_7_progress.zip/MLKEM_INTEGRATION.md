# ML-KEM integration boundary

The target demo assigns ML-KEM-512 Encaps to the PC and Decaps to the Zynq PL.
KeyGen is performed when provisioning the board and does not need to run for
every client connection.

```text
PC: ML-KEM Encaps -> ciphertext
                         Ethernet (stage 8)
Zynq PS: receive ciphertext and select session slot
                         AXI-Lite, no DMA
Zynq PL: ML-KEM Decaps -> session KDF -> AEAD session table
```

## Implemented PL Decaps path

```text
SK/CT BRAM
  -> d10/d4/12-bit unpack
  -> K-PKE.Decrypt
     NTT(b) -> BaseMul(s,b) -> add -> INTT -> v-s^T b -> Decode1
  -> recovered message m
  -> SHA3-512 G(m || H(ek))
```

The K-PKE.Decrypt path uses the verified `mlkem_poly_accelerator.sv` through
an internal BRAM bridge, so intermediate polynomials no longer travel through
the PS. Matrix generation uses SHAKE128 plus rejection sampling; noise
generation uses SHAKE256 plus eta2/eta3 CBD sampling.

## AXI-Lite loading interface

`mlkem_decaps_axi_lite_frontend.sv` provides auto-incrementing 32-bit memory
windows for the 1,632-byte secret key and 768-byte ciphertext. The matching
bare-metal functions are in `ps_driver/mlkem_decaps_hw.c`. This interface is
deliberately DMA-free because the transfer occurs only during a handshake and
is small enough for the first ZedBoard demo.

## Still required for standards-compliant Decaps

K-PKE re-encryption, full ciphertext comparison, implicit rejection and final
KDF selection must be connected before the PL output may be treated as an
ML-KEM shared secret. Until those blocks and the invalid-ciphertext KAT pass,
the existing verified PS-Decaps route remains the safe end-to-end fallback.
